# XArrPay 插件仓库源
XArrPay 非官方收集的插件仓库

欢迎提交 PR

# 使用方式

在XArrPay 商户版中填写插件源
`https://raw.githubusercontent.com/touchear/xarr-pay-plugins/refs/heads/main/package.json`

国内用户可设置加速地址
`https://ghp.ci/`

或使用源地址为
`https://ghp.ci/https://raw.githubusercontent.com/touchear/xarr-pay-plugins/refs/heads/main/package.json`



# 使用声明

本仓库所包含的代码和内容仅供学习与研究用途。我们无法保证本仓库中的内容不涉及违法或侵犯他人权益。在使用本仓库内的任何内容时，请您务必遵守相关法律法规，并自行承担所有可能的后果。

## 免责声明

- 本仓库作者不对任何因使用本仓库而引发的法律责任承担责任。
- 本仓库的内容可能会包含相关知识产权或其他法律保护的条款，请在使用前确保您拥有相应的合法权利。

## 违规处理

如发现本仓库中存在任何违法或侵权内容，请及时联系我进行处理。您可以通过以下方式联系我：

- 邮箱: [gerui434@gmail.com](mailto:gerui434@gmail.com)

谢谢你的理解与配合。
